
There many ways to contribute to BotUI.


### Help with issues

See if there are any open issues you help with.


### Write examples

You can also [write examples](https://github.com/moinism/botui-examples) for BotUI.


### Code contribution

You can read about code contribution [here](https://docs.botui.org/contribute.html).

#### For dev/publishing

- checkout to publish branch
- run `changeset` in root.
- run `changeset:version`.
- push changes to publish branch.
- after: switch to dev/main branch and pull changes for publish