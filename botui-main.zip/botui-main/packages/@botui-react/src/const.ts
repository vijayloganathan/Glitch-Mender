

export const defaultTexts = {
  buttons: {
    confirm: 'Done',
    cancel: 'Cancel',
  },
  messages: {
    cancel: 'Cancelled'
  },
}