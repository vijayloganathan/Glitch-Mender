export enum CSSClasses {
  botui_wait = "botui_wait",
  botui_button = "botui_button",
  botui_action = "botui_action",
  botui_message = "botui_message",
  botui_container = "botui_container",
  botui_message_list = "botui_message_list",
  botui_app_container = "botui_app_container",
  botui_message_content = "botui_message_content",
  botui_action_container = "botui_action_container",
  botui_message_container = "botui_message_container"
}

export type Renderer = Record<string, (...args: any) => JSX.Element | null>