# botui

## 1.1.3

### Patch Changes

- remove `next` channel

## 1.1.2

### Patch Changes

- corrects wait return type and adds an overload for it too

## 1.1.1

### Patch Changes

- fix exports and types

## 1.1.0

### Minor Changes

- 6c8d94e8: add `exports` in package.json, add return type for `.action.set()`

## 1.0.5

### Patch Changes

- 5b59a5b0: `.next` can pass on meta as second param

## 1.0.4

### Patch Changes

- `meta.previous` is a `Block` type
