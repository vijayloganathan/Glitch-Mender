
# `botui` Package

You can install the core botui package using:

```
npm i botui
```

Next, Read the API [reference](./1-reference.md) to learn how to use it.