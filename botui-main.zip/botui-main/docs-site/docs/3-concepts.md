

# Core vs UI packages

## Data

Work-in-progress

JSON data structrure
