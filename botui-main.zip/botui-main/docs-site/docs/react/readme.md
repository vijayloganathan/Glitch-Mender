
# `@botui/react` Package

```
npm i @botui/react
```

Read the API [reference](./1-reference.md) or learn how to add [custom actions and messages](./2-custom.md).