
# Installation

It's available on [NPM registery](https://npmjs.org/botui) and you can install it using your favorite package manager. Here is an example with `npm`:

Install `botui` core library and its React package.

```bash
npm i botui @botui/react
```

You can think of the core library as the `bot` and the framework packages as the `UI` parts of BotUI, respectively.

## Quickstart

You can also just clone our [🪄 quickstart](https://github.com/botui/react-quickstart) repo and get started.