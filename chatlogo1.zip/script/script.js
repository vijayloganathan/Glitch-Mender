let editor;
var inputs = $("#input");

$("#run").click(function(){
    $.ajax({
        url: "server.php",
        method: "POST",
        data: {
            code: editor.getSession().getValue(),
            input: inputs.val()
        },
        success: function(response){
            $(".code_output").text(response);
        }
    })

})